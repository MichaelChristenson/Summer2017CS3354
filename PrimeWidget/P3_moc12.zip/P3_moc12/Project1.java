import java.util.*;
import java.awt.*;
import java.io.PrintWriter;
import java.io.IOException;

public class Project1{
	public static void main(String[] args) throws IOException{
		gui view = new gui();
	}
}
